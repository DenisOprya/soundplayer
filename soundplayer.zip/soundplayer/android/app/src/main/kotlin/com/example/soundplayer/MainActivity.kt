package com.example.soundplayer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
